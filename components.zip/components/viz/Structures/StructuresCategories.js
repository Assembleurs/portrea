import { useEffect, useState, useRef } from 'react';
import useSWR from 'swr';

async function fetcher(url) {
  const res = await fetch(url);
  const data = await res.json();
  return data.features;
}

const StructuresCategories = ({ irisCode, id }) => {
  const [map, setMap] = useState(null);
  const mapRef = useRef(null);
  const { data, error } = useSWR(`/api/structures/structures-inclusion?irisCode=${irisCode}`, fetcher);

  useEffect(() => {
    if (!map && document.getElementById(id)) {
      import('leaflet').then(L => {
        const newMap = L.map(id).setView([50.603354, 3.888334], 9);
        mapRef.current = newMap;

        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
            '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
            'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        }).addTo(newMap);

        setMap(newMap);
      });
    }
  }, [map, id]);

  useEffect(() => {
    if (data && map) {
      import('leaflet').then(L => {
        data.forEach(feature => {
          const { coordinates } = feature.geometry;
          const marker = L.marker([coordinates[1], coordinates[0]]);
          marker.addTo(map);
        });
      });
    }
  }, [map, data]);

  if (error) return <div>Failed to load data</div>;
  if (!data) return <div>Loading...</div>;

  return <div id={id} style={{ height: "500px", width: "100%" }}></div>;
};

export default StructuresCategories;
